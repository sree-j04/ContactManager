/*
 * sree jessu
 * ContactManagerV3
 * 06/01/2021
 * a program that uses GUI to create a contact menu, allowing users to perform several functions
 * input: available option from menu
 * output: method that the option is associated with
*/
package GUI;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.TableRowSorter;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class ContactManagerV3 extends JFrame implements ActionListener{
	
	//create a table with column labels
	static Object[] columns = {"First Name", "Last Name", "Address", "Phone number", "Email"};
	
	//create an array of objects to set the row data
	static final Object[] row = new Object[15];
	
	//declare and initialize a table of contact values
	static final JTable table = new JTable();
	
	public static void main(String[] args) throws IOException{
		//creates a new GUI window
		ContactManagerV3 window = new ContactManagerV3();
		//allows user to exit GUI when it is closed
	    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    //title of the GUI window
	    window.setTitle("Contact Manager");
	    //size of the GUI window
	    window.setSize(800,600);
	    //boolean that makes the GUI window visible
	    window.setVisible(true);  
	}
	
	/*
	 * sree jessu
	 * ContactManagerV3
	 * 06/01/2021
	 * a method that creates the menu and the clickable options in it
	*/
	public ContactManagerV3(){
		//declare JMenuBar, JMenu, and JMenuItem variables
		JMenuBar menuBar;
	    JMenu menu;
	    JMenuItem menuItem;
	    
	    //create a new JMenuBar object
	    menuBar = new JMenuBar();
	    setJMenuBar(menuBar);
	    //name the new menu "Contacts"
	    menu = new JMenu("Contacts");
	    //add the menu option to the menu bar
	    menuBar.add(menu);
	    
	    //create a new menu item known as Generate Table
	    menuItem = new JMenuItem("Generate Table");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	    
	    //create a new menu item known as Save Contacts
	    menuItem = new JMenuItem("Save Contacts");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);
	    
	    //create a new menu item known as Load Contacts
	    menuItem = new JMenuItem("Load Contacts");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);    	    	  
	    
	    //create a new menu item known as Sort Contacts
	    menuItem = new JMenuItem("Sort Contacts");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	    
	    //create a new menu item known as Quit
	    menuItem = new JMenuItem("Quit");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	}
	
	/*
	 * sree jessu
	 * generateTable
	 * 06/01/2021
	 * a method that builds a table where values can be added, edited, and deleted
	*/	
	public static void generateTable(){
		//create JFrame
		JFrame frame = new JFrame();		
		
		//create a default table model
		final DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);

		//set the model to the table
		table.setModel(model);

		//set background colors
		table.setBackground(Color.CYAN.brighter());
		//set foreground colors
		table.setForeground(Color.black);
		//create a font
		Font font = new Font("", 1, 18);
		//set the font to the table
		table.setFont(font);
		//set the row height
		table.setRowHeight(30);

		//create JTextFields to hold the contact information
		final JTextField firstName = new JTextField();
		final JTextField lastName = new JTextField();
		final JTextField address = new JTextField();
		final JTextField phoneNumber = new JTextField();
		final JTextField email = new JTextField();

		//create button that helps add the contact information
		JButton btnAdd = new JButton("Add");
		//create button that helps delete the contact information
		JButton btnDelete = new JButton("Delete");
		//create button that helps edit the contact information
		JButton btnEdit = new JButton("Edit");
		
		//set the bounds for each of the information fields
		firstName.setBounds(20, 220, 100, 25);
		lastName.setBounds(20, 250, 100, 25);
		address.setBounds(20, 280, 100, 25);
		phoneNumber.setBounds(20, 310, 100, 25);
		email.setBounds(20, 340, 100, 25);

		//set the bounds for each of the buttons
		btnAdd.setBounds(150, 220, 100, 25);
		btnEdit.setBounds(150, 265, 100, 25);
		btnDelete.setBounds(150, 310, 100, 25);

		//create a JScrollPane to make a scrollable table
		JScrollPane pane = new JScrollPane(table);
		//set the bounds of the table
		pane.setBounds(0, 0, 880, 200);
		//make the frame layout null
		frame.setLayout(null);
		//add the scroll pane to the frame
		frame.add(pane);

		//add the text fields to the frame
		frame.add(firstName);
		frame.add(lastName);
		frame.add(address);
		frame.add(phoneNumber);
		frame.add(email);

		//add the buttons to the frame
		frame.add(btnAdd);
		frame.add(btnDelete);
		frame.add(btnEdit);

		
		
		/*
		 * sree jessu
		 * actionPerformed for add button
		 * 06/01/2021
		 * a method for the add button that adds row to the table when clicked
		*/
		btnAdd.addActionListener(new ActionListener(){						
			@Override
			public void actionPerformed(ActionEvent e){
				//add the information typed in the text field to the rows
				row[0] = firstName.getText();
				row[1] = lastName.getText();
				row[2] = address.getText();
				row[3] = phoneNumber.getText();
				row[4] = email.getText();
				
				//add the new row to the model
				model.addRow(row);
			}
		});

		/*
		 * sree jessu
		 * actionPerformed for delete button
		 * 06/01/2021
		 * a method for the delete button that deletes a row from the table when clicked
		*/
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				if(i >= 0){
					//removes a row from the table
					model.removeRow(i);
				}else{
					System.out.println("Sorry! The row could not be deleted!");
				}
			}
		});

		/*
		 * sree jessu
		 * mouseListener for delete button 
		 * 06/01/2021
		 * a mouse clicker method for the delete button 
		*/
		table.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				
				//set the values for the deleted contact to empty
				firstName.setText(model.getValueAt(i, 0).toString());
				lastName.setText(model.getValueAt(i, 1).toString());
				address.setText(model.getValueAt(i, 2).toString());
				phoneNumber.setText(model.getValueAt(i, 3).toString());
				email.setText(model.getValueAt(i, 4).toString());
			}
		});

		/*
		 * sree jessu
		 * actionPerformed for edit
		 * 06/01/2021
		 * a method for the view button that allows the user to click on a row and change values
		*/
		btnEdit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				//if the row is 0 or above, update the row
				if (i >= 0){
					model.setValueAt(firstName.getText(), i, 0);
					model.setValueAt(lastName.getText(), i, 1);
					model.setValueAt(address.getText(), i, 2);
					model.setValueAt(phoneNumber.getText(), i, 3);
					model.setValueAt(email.getText(), i, 4);
				}else{
					//if it is less than 0, print error statement 
					System.out.println("Edit Error");
				}
			}
		});
		//frame parameters
		frame.setSize(900, 400);
		//frame location
		frame.setLocationRelativeTo(null);
		//allows user to exit the application after clicking the x
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//makes sure the frame can be seen
		frame.setVisible(true);				
	}
	
	/*
	 * sree jessu
	 * saveBook
	 * 06/05/2021
	 * method prints entries in the file
	 * input: n/a
	 * output: saves contacts in file
	 */
	public static void saveBook() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the save message label
		JPanel panel = new JPanel();
		//create a new label that gives the save message
		final JLabel saveMessage = new JLabel();
		
		//declare and initialize the print writer
		PrintWriter output = new PrintWriter(new FileWriter("contacts.txt"));
		//print the contents of the table
		output.println(row.length);
		//goes through each entry and prints it in the file
		for(int i = 0; i < row.length; i++){	
			output.println(row[i]);
		}
		//label that sends a message that the contacts are being saved
		saveMessage.setText("Saving Contacts ...");
		//add the label to the panel
		panel.add(saveMessage);
		//add the panel to the frame
		frame.add(panel);
		
		//set the frame size
		frame.setSize(100, 100);		 
        frame.show();
		//closes file
		output.close();
	}
	
	/*
	 * sree jessu
	 * loadBook
	 * 06/05/2021
	 * method writes array values to file
	 * input: array values
	 * output: writes to file
	 */
	public static void loadBook() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the load message label
		JPanel panel = new JPanel();
		//create a new label that gives the load message
		final JLabel loadMessage = new JLabel();
		
		//declare and initialize the buffered reader
		BufferedReader in = new BufferedReader(new FileReader("contacts.txt"));
		
		//label that sends a message that the contacts are being loaded
		loadMessage.setText("Loading " + table.getRowCount() + " contacts...");
		//add the label to the panel
		panel.add(loadMessage);
		//add the panel to the frame
		frame.add(panel);
				
		//set the frame size
		frame.setSize(100, 100);		 
		frame.show();
		
		//goes through each index and takes contact input
		for(int i = 0; i < table.getRowCount(); i++){
			row[i] = in.readLine();
		}
	}
	
	/*
	 * sree jessu
	 * sort
	 * 06/01/2021
	 * method sorts all contacts in alphabetical order
	 * input: n/a
	 * output: alphabetized contacts
	 */
	public static void sort() throws IOException{
		//create a new table row sorter
		TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());
		//set sorter for the rows in the contact table
		table.setRowSorter(sorter);
		//make a new array list named sortKeys
		List<RowSorter.SortKey> sortKeys = new ArrayList<>();
		
		//declare and initialize integer, columnIndexToSort to 1
		int columnIndexToSort = 1;
		sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
		
		//set sorter to sortKeys
		sorter.setSortKeys(sortKeys);
		sorter.sort();
	}
	
	/*
	 * sree jessu
	 * actionPerformed
	 * 06/02/2021
	 * method corresponds the user clicked option to a method
	 * input: menu option
	 * output: function(method) corresponding to the option
	 */
	@Override
	public void actionPerformed(ActionEvent e){
	    String event = e.getActionCommand();
	    //menu items and corresponding method response
	    if(event.equals("Quit")){
	      hide();
	      System.exit(0);
	    }else if(event.equals("Generate Table")){
	    	generateTable();
	    }else if(event.equals("Save Contacts")){
	    	try{
				saveBook();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }else if(event.equals("Load Contacts")){
	    	try{
				loadBook();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }else if(event.equals("Sort Contacts")){
	    	try{
				sort();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }
	}
}