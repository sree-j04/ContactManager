package GUI;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

/*
 * FirstGUI is the first GUI taught in ICS4U
 * JFrame is the superclass of FirstGUI and ACtionListener is an interface that allows us to detect ActionPerformed
 * which is called when an action is performed.
 */
public class GUIExample extends JFrame implements ActionListener
{

	/*
	 * These are the class variables, imageFile is a temporary String that will contain the URL of the image to display
	 */

	static String imageFile = "banana.gif";

	/*
	 * contentPane will be the main object of your GUI,
	 * here you can add text fields, labels, buttons, etc.
	 */
	Container contentPane;

	//Image panel is used to display images, it is like a magnet to be placed on a fridge door
	ImagePanel imagePanel;

	/*
	 * Other than initially running the software, once either loadPanel or imagePanel have been set then
	 * the contentPane will always be displaying one of them
	 */
	
	//loadPanel is used to get the URL from the user and present the "Load" button, it is like another magnet
	JPanel loadPanel;

	//Here are a few more graphic objects we will use.
	JLabel L1;	//labels an object
	JTextField fileNameField;	//textfield for getting the URL
	JButton addButton;			//button for "Load File", sets imageFile


	/*
	 * Default constructor of the FirstGUI class
	 * The constructor creates a menubar at the top of the window
	 * first by creating the menu, then creating and adding menu items
	 */
	public GUIExample()
	{

		//declare and initialize the menu
		JMenuBar menuBar;
		JMenu menu;
		JMenuItem menuItem;

		//create the menubar
		menuBar = new JMenuBar();

		//This sets the menuBar in place
		setJMenuBar(menuBar);

		//Add the File option to the menubar
		menu = new JMenu("File");
		menuBar.add(menu);

		//Add "Load Image" to the menu item File
		menuItem = new JMenuItem("Load Image");
		menuItem.addActionListener(this);
		menu.add(menuItem);

		//Add "Quit" to the menu item File
		menuItem = new JMenuItem("Quit");
		menuItem.addActionListener(this);
		menu.add(menuItem);

		//Add menu item Display
		menu = new JMenu("Display");
		menuBar.add(menu);

		//Add "Display Image" to the menu item Display
		menuItem = new JMenuItem("Display Image");
		menuItem.addActionListener(this);
		menu.add(menuItem);

	}


	//displayImage() displays the image onto the screen in the Content Pane
	//It is called when the user chooses the menu item Display Image
	public void displayImage()
	{

		//set the variable contentPane to the Content Pane (where the image will be displayed)
		contentPane = getContentPane();
		//Create the image

		//If the loadPanel is still on the contentPane, remove it.
		if(loadPanel !=null){
			
			contentPane.remove(loadPanel);
		}

		//Create an image object from the image: imageFile
		Image image = Toolkit.getDefaultToolkit().getImage(this.imageFile);

		//Create the image panel object
		imagePanel = new ImagePanel(image);

		//Add the image panel to the contentPane in the center
		contentPane.add(imagePanel, BorderLayout.CENTER);

		//Validate refreshes the screen
		validate();
	}


	/*
	 * load() is called when the user selects "Load Image", 
	 * the contentPane is changed from the imageDisplay to the load display
	 * that asks for the URL of the image and has the "Load File" button
	 * When the user clicks "loadFile" the imageFile variable is set to the URL in the textfield
	 */
	public void load()
	{

		//Find the front of the fridge
		contentPane = getContentPane();

		//Error checking, remove imagePanel if it exists.
		if(imagePanel != null)
			contentPane.remove(imagePanel);

		//Create a new panel
		loadPanel = new JPanel();

		L1 = new JLabel ("File Name:");

		loadPanel.add(L1);
		fileNameField = new JTextField(20);
		loadPanel.add(fileNameField);

		//Add the addButton to show "Load File"
		addButton = new JButton("Load File");
		addButton.addActionListener(this);
		loadPanel.add(addButton);

		//display the load panel
		contentPane.add(loadPanel);

		//refresh the screen
		validate();
	}

	/*
	 * actionPerformed is called when an event (such as mouse click) occurs.
	 * When the user clicks on an object that has an ActionListener attached to it
	 * (such as several lines above with the JButton("Load File")) this method is called
	 * with the event that fired. If the Load File button were clicked, "Load File" would be send to actionPerformed.
	 * Using if statements the program can determine the necessary action.
	 */
	public void actionPerformed(ActionEvent e)
	{
		//get the name of the action
		String event = e.getActionCommand();

		//If the event is "Display Image" call displayImage()
		if(event.equals("Display Image"))
		{
				displayImage();

		}
		//if the event is Load Image, then call load()
		else if(event.equals("Load Image"))
		{
			load();
		}
		//if the event is Load File, then set imageFile to the fileNameField
		else if(event.equals("Load File"))
		{
			imageFile = fileNameField.getText();
		}
	}

	//Main Method
	public static void main(String[] args) throws IOException
	{


		//Create an object of type FirstGUI
		GUIExample window = new GUIExample();

		//Set the text at the top of the window
		window.setTitle("My First GUI - Image Displayer");


		//Set the initial size, and make it visible
		window.setSize(800,600);
		window.setVisible(true);

	}

}

/*
 * imagePanel is another subclass of JPanel. It is used to create the image display
 */
class ImagePanel extends JPanel {

    //Image variable
    Image image;

    //Constructor for the ImagePanel
    public ImagePanel(Image image) {

    	//set the image
    	this.image = image;
    }

    //This draws the image on the panel
    public void paintComponent(Graphics g) {
        super.paintComponent(g); //paint background
        
        //Draw image at its natural size
        g.drawImage(image, 0, 0, this); 
    }
}



